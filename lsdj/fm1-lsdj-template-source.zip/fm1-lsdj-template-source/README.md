# GameDude - FM-1 / SMK37 — v2.0

## LSDj Burrito: screen mirror without torn panels, 30 a second (FM-1_987)

- **The web page's screen mirror no longer shows torn or missing panels.** FM-1_983-986
  read the emulator's picture (gp_pixels), which CPU1 starts drawing the next frame into as
  soon as the panels are scaled out, so rows sent later could lack the FX panel or menu.
  The mirror now reads the LCD image (`screen`, written by the main loop only right before
  display_frame, the loop the mirror runs in): lsdj_link_px reads picture pixel (x, y) back
  from it (row ceil(3y/2), columns A,A,B, bytes swapped). No RAM added; the page's protocol
  is unchanged. harness/mirror_tear_emu.mjs: with panels up the old source differed from
  the LCD in about 1 sample in 15 (up to 121 rows), the LCD image never.
- The page looks for changes every 33 ms (was 50) over USB: 30 a second.

## LSDj Burrito: cursor FX on other LSDj versions (FM-1_986)

- **The effects follow LSDj's cursor on more LSDj versions.** The web page recognises a
  program by its code banks (0-7, 1B-1F) with the palette colours (bank 1) and palette
  names (bank 1B) blanked, so custom palettes and kits (blank kit slots too) keep the
  match. LSDj 9.3.9 that way: every helper (slot byte 148 = 1). LSDj 9.4.0, 9.2.L, 9.1.C,
  8.4.9, 8.4.2 and 4.6.2: slot byte 148 = 2 with the cursor and tempo bytes at 149 and
  151 (found with harness/find_cursor.c and find_tempo.c), so cursor-following effects
  and the LFO tempo work; SEQ live mode, tempo editing, cues and MIDI sync still need
  LSDj 9.3.9 (src/lsdj_slot.h, cursor_detect in firmware/board.c).

## LSDj Burrito: faster screen mirror (FM-1_985)

- **The web page's screen mirror is several times faster.** One request (0x27
  SCREEN_SYNC) carries the hashes the page holds; the FM-1 answers with its own and
  then sends the changed rows by itself (0x28 SCREEN_PIXELS), packed 7 bits to a byte
  with 0-4 bits a pixel, instead of one request per row. Rows go from the main loop,
  one at a time once the USB SysEx queue is empty. USB only; over Bluetooth (and with
  FM-1_983/984) the page reads rows one by one as before. No RAM added.

## LSDj Burrito: two effects areas (FM-1_984)

- **Channel effects and master effects are apart.** Turning KNOB 1-4 or SELECT pops up
  the channel pages (FILTER, DRIVE, LFO, LO-FI) for the channel under the cursor, for a
  moment, as before. The **FX button** opens the master pages (MASTER, ECHO, ECHO MOD;
  C4-F4 mute) and keeps them open until FX is pressed again.

## LSDj Burrito: screen mirror on the web page (FM-1_983)

- **The web page shows the FM-1's screen** (above Effects): the 160x144 picture the LCD
  shows, panels included, read over the web link (ops 0x25 SCREEN_INFO, 0x26 SCREEN_ROW,
  `firmware/lsdj_link.h`). The page asks only for the 8-row bands whose hash changed,
  so a cursor move costs a few rows. View only; nothing is read unless the page asks,
  and no RAM is added (rows are read from the emulator's picture).

## LSDj Burrito: master pages apart from the channel pages, autosave (FM-1_982)

- **FILTER K2 is the echo send**, next to K1 Channel FX; the filter type moved to
  LO-FI K3. Save words, link and MIDI CCs are unchanged (the knob layout is not in
  the saved words: the webpage picks it from the firmware number).
- **SELECT stops** at the first and last FX page, so turning back always reaches
  FILTER (PAGE WRAP brings back going round).
- **A muted channel's panel is grey** (still adjustable), and turning one of its
  effects puts why on the title row for the POPUP TIME: `PU1 MUTED: KEYS` / `WEB` /
  `CC81`.
- **MIDI CC to effects shows** as a message (`PU1 CUTOFF` / `MIDI CC 74: 40`);
  **CC OUT** sends each turned FX knob's CC over USB (channels as CC FX, 1 if off).
- **KNOBS: CHANNELS**: SELECT picks one per-channel effect (14, in page order, then
  ECHO and ECHO MOD as pages), K1-K4 set it on PU1 PU2 WAV NOI; muted columns grey.
- **PAGE LIGHTS**: a soft black key (C#4 D#4 F#4 G#4 A#4 C#5, none a Game Boy
  button) shows FX page 1-6, or LSDj 9.3.9's SONG CHAIN PHRASE INSTR TABLE GROOVE.
- **MODE LIGHTS**: HOME's note / button change plays the power-on sweep once every
  key and button is let go.
- **BATTERY**: three cells (Felucca's thresholds) or USB after "FX" in the screen
  map and on the settings list; BATTERY LOW once. LIVE carries it (a byte after the
  effects words; older pages ignore it).
- **FX THEME**: the FX panel, lists and messages in a theme of their own, or MATCH
  (default) LSDj's.
- All switches: SETTINGS / FX+LIGHTS (`firmware/lsdj_feat.h`, save-store record 23,
  link ops 0x19 / 0x1A). The overlay font is packed bytes now (same pixels, 1.2 KB less).

## LSDj Burrito: echo back with the channel pages (FM-1_978)

ECHO and ECHO MOD are back in the tap-FX / SELECT pages (1/6..6/6, after FILTER,
DRIVE, LFO, LO-FI); holding FX shows only MASTER (All FX, compressor) and the
channel strip. The echo itself is unchanged: one echo shared by every channel, each
channel with its own send (LO-FI K3). Saved setups on ECHO / ECHO MOD keep that page.

## LSDj Burrito: hold FX for the master page (FM-1_977)

The effects pages are split by what they act on:

- **Tap FX** (or turn SELECT): the channel pages FILTER, DRIVE, LFO, LO-FI
  (1/4..4/4), on the channel under LSDj's cursor.
- **Hold FX**: the master pages MASTER, ECHO, ECHO MOD (1/3..3/3), shared by
  every channel. SELECT turns them and K1-K4 play them while FX is held; the
  page closes when FX is let go. A channel strip (row 14) shows PU1 PU2 WAV NOI,
  lit while playing; C4 D4 E4 F4 mute / unmute them, and their key lights are
  lit while the channel plays. These are the same mutes as MIDI CC 81 and the
  webpage's channel buttons (link op 0x24 MUTE_SET, live only, never saved).
  The old hold shortcuts G4-C5 (channel FX) and D5 (freeze) are gone: channel FX
  is FILTER K1 and freeze is ECHO MOD K4.

A quick tap (under 250 ms, nothing turned) never shows the master page. Saved
setups that were left on a master page open on FILTER.

## LSDj Burrito: SEQ and the other LSDj helpers in web builds (FM-1_976)

Web-installed (generic template) builds used only the cursor address from the
verified LSDj 9.3.9 profile, so SEQ (live / song mode), EDIT tempo, ARP song
cues, MIDI clock / KEYBD sync and the PLAY beat light did nothing. The profile
is set by the browser only when the program banks' SHA-256 matches the verified
9.3.9 program, and every one of these addresses belongs to that program, so
FM-1_976 enables all of them for profile 1. Unknown programs still get none.

## LSDj Burrito: master FX controls (FM-1_975)

The first FX page is **MASTER**: K1 switches **All FX** on/off; K2 is the
shared compressor. Turning All FX off produces the original dry mix, including
channel mutes. Channel effects, echo and compressor settings are retained;
their internal state keeps advancing so re-enabling does not resume a stale
echo or LFO. Bypass is not a CPU-saving mode.

| Page | K1 | K2 | K3 | K4 |
| --- | --- | --- | --- | --- |
| 1 MASTER | All FX | Compressor | - | - |
| 2 FILTER | Channel FX | Filter type (979: Echo send) | Cutoff | Resonance |
| 3 DRIVE | Drive | Distortion | Warmth | - |
| 4 LFO | Rate | Depth | Shape | Destination |
| 5 LO-FI | Crush | Decimate | Echo send (979: Filter type) | - |
| 6 ECHO | Time | Feedback | Mix | Tone |
| 7 ECHO MOD | Wobble | Sync | Mode | Freeze |

SELECT changes pages; the screen map uses the same numbers across two rows.
Unused knobs are blank/inert. Existing FX-held mute, channel bypass and freeze
shortcuts are unchanged. Accent bars and the no-channel-tint styling remain.
The webpage mirrors these pages on supporting firmware, retaining the original
layout on older firmware and explicitly explaining the unavailable master switch.

The 17-word FX format uses byte 37 = 2 for this layout and byte 39 for global
bypass (0 on, 1 off). SAVE/Keep and settings backups preserve the switch.
Legacy saved setups default to All FX on and migrate page indices. Older live
clients preserve effects they cannot control, including global bypass.
The unresolved physical cursor-following report is separate; this reorganization
does not claim to fix it.

## LSDj Burrito: alpha 71 effects display

The on-device effects panel keeps LSDj's font, palette, four knob columns,
active-knob readout, channel text and bottom labels. Amount bars now have eight
segments: each spans 16 raw setting values (`10` hex), with partial fill between
boundaries. The shared `00`, `20`, `40`, `60`, `7F` ruler matches the hex setting
under each amount bar; `00` is empty and `7F` is full. Screen pixels quantize the
fill, so the numeric value remains the precise reading.

Alpha 71 fills the bars with the selected theme's accent colour instead of
LSDj's muted value-field shade. Classic uses amber; other presets and CUSTOM
use their own accent. The channel-column tint has been removed; channel identity
remains in the text, and every bar has the same normal background.
Empty markers, segment gaps, text and choice selectors keep their existing
styling. Custom themes should use an accent distinct from their background.
Rendering tests check accent/background separation across all preset entries,
all four background shades and identical rendering for every channel selection.

Filter types, distortion modes, LFO shapes/destinations and on/off modes appear
as choice lists, with only the selected name inverted. Their two-letter codes
match the value row; turning the knob shows the full name in the top readout.
The amount scale is a **raw setting**, not Hz, milliseconds or a linear measure
of audible intensity. Echo time and LFO rate retain their actual time/note/rate
readouts when active, including in synced modes.

Cue/tempo panels keep their previous display. Knob behavior, DSP, audio buffers
and saved-effect formats are unchanged. `tests/lsdj_native.c` checks all 128
amount values, segment boundaries, all 2-6-choice selection positions and panel
bounds; `tests/lsdj_fx_ui.c` checks matching selector/value labels and raw scales.
The refreshed FM-1_974 webpage template includes these display changes and the
CPU1 save fixes, but retains its generic-ROM limitations. Physical alpha 71
and template-combination confirmation are separate from host/emulator checks.

## LSDj Burrito: experimental webpage template

This fork also builds the ROM-free FM-1_987 LSDj template for the sibling Burrito
website. This is separate from the upstream GameDude library workflow below.
Normal ROM builds use the current alpha identity (FM-1_987 for alpha 87).

From this repository in WSL:

```sh
python3 tools/lsdj_template.py --toolchain /root/.jieli/toolchain --sdk /root/ac79-sdk
```

Output is `build/lsdj-template/fm1-lsdj-template.fwsc` and `template.json`;
`--output-dir` overrides the destination. The build also replaces intermediate
`build/fm1` files. SDK hashes, image bounds, erased slot, package round trip and
simulated OTA are checked. Only the ROM-free package and matching metadata may
be copied to the sibling site's `lsdj/` directory. Never publish ROM-bearing builds.

The current template has 31 stored 16 KiB banks plus a 256-byte header. The browser
requires explicit kit selection if the ROM exceeds this budget and preserves
logical bank numbers. Unrecognized program/data banks cannot be discarded.
The dynamic slot parser validates header/data CRCs and a complete sequential bank
map before emulation. The browser enables the read-only cursor profile only
when the program SHA-256 matches known LSDj 9.3.9 code; custom or omitted sample
kits do not change this fingerprint. Slot byte 148 selects that profile under
the header CRC. Cursor-following FX is restored without the channel tint.
Unknown programs explicitly fall back to ALL channels, never title-based
address guessing. Tempo shortcuts, MIDI clock integration and cues remain
disabled in generic builds. Back up saves before switching versions.

FM-1_974 adds read-only installed-cartridge export for future updates without
choosing the original ROM again. The link's `CART_INFO` (0x22) reports slot
length/header CRC/data CRC; `CART_READ` (0x23) returns the requested offset and
at most 120 bytes, within the validated immutable slot only. No arbitrary
addresses, saves, writes, pause or flash operations are exposed. Save imports
block these reads. Non-slot builds and older firmware report unsupported.

The page verifies chunks, both CRCs and slot layout, reconstructs missing banks
as FF, and inserts that ROM into the latest verified template. All installed
kits stay selected and locked; if they cannot fit, preparation is refused.
The original-ROM path remains available for explicit kit changes. Previously
omitted samples cannot be recovered. Readback neither backs up songs/settings
nor installs firmware; installation is a separate explicit action.

The first readback-capable firmware must be installed once using a private ROM.
974 is that bootstrap release; no physical readback confirmation has been
reported. `tests/lsdj_link.c` checks bounds, retries, unavailable slots and
read-only state; `tests/lsdj_cartridge_link.c` exposes the real C protocol over
stdin/stdout for the site's `tests/device-update.mjs` integration tests.

This template is **experimental, not hardware-validated**. Packaging and simulated
OTA success do not establish boot/audio correctness or recoverability after
interrupted flashing. `tests/lsdj_slot.c` tests slot parsing; `tests/lsdj_rom.c`
accepts a private browser-generated slot for a 600-frame host emulator smoke test
and, with a recognized cursor profile plus a private 128-KiB SONG-screen save
as the second argument, checks all four real ROM cursor positions and
channel-isolated cutoff changes.
The sibling site's `tests/loader.mjs` tests browser packing and optional local ROMs.

**Now with Bluetooth and Multi-game storage.**

- Install the core once, then add games over Bluetooth or USB.
- Keep multiple games installed across power cycles, select them on the device, and see remaining space.
- Manage the same game library from either connection, including play and delete.
- Separate **Install firmware** and **Add games** tabs, with automatic firmware selection and drag-and-drop games.

The public release name is v2.0; internal USB firmware build numbers remain unchanged for device compatibility. Cartridge save RAM remains volatile.


Play original Game Boy cartridges in your browser or send them to the FM-1 / SMK game library.

**[Play GameDude](https://chancethemaker.github.io/gamedude-fm1-smk/)** | **[Source](https://github.com/ChanceTheMaker/gamedude-fm1-smk)**

## Browser player

Drop in a `.gb` file or a ZIP containing one `.gb`. ROM processing and firmware preparation happen in your browser. No game files are uploaded to a server. Nine licensed homebrew games/apps and an original diagnostic cartridge are included; commercial game ROMs and Nintendo boot ROMs are not.

Choose **FM-1**, **SMK-37 Pro**, **SMK-37 Elite**, or **Game Boy** in the Simulator selector. The Game Boy option adds a classic gray handheld shell, green display and magenta A/B buttons. FM-1 and SMK37 offer clickable instrument keys and pads. Switching layouts keeps the current game running.

The colorful GameDude logo drops, bounces, releases a burst of colored pixels and finishes with a travelling sparkle. A quiet three-note chime plays on landing when sound is enabled. The 1.5-second intro respects reduced motion in the browser (still logo with chime). Volume starts at 25%. WASD or arrow keys move. Space is B, Enter is A, P is Start, and Shift is Select. Z/X remain alternate B/A keys; actions depend on the game. On-screen controls also work. Cartridge RAM saves automatically in this browser, with `.sav` import/export for games with RAM.

## Install and load games

1. Open **Install firmware**, choose FM-1 or the exact SMK model, connect USB, and install GameDude. No ROM or firmware file selection is required.
2. Open **Add games**. Choose a licensed homebrew or drop a `.gb` / `.zip` cartridge onto the picker or simulator.
3. Choose the instrument and Bluetooth or USB. Both transports use the same persistent game library.
4. On the device, hold PLAY + REC for two seconds to return to the library. Directional keys/pads select a game; REC or A starts it. PLAY opens Bluetooth loading. REC returns from loading to the library.

Individual games are limited to 256 KiB. FM-1 has 360 KiB of library storage and SMK has 392 KiB; the device and website show free space. CRC checks and redundant catalogs protect completed games during interrupted additions/deletions. Battery save RAM is still volatile. Installing firmware replaces the library.

Internal builds are FM-1_938 and SMK-37_938; the release name is **v2.0**. The older 937 single-cartridge template remains only as a packaging/test fixture.

### Local preview and Windows USB

Run `python tools/serve.py --port 8890` and open http://localhost:8890/. Local SMK installation uses short-lived native USB stages to avoid the Windows legacy MIDI handoff hang. This requires the local MIDI Python dependencies and verified stock package under ignored `build/`; the helper accepts only the pinned core or verified stock restore. Hosted GitHub Pages still uses browser MIDI: the native helper does not fix Chrome's Windows legacy MIDI driver there.

This owner's SMK needs the previously verified, device-specific RF calibration fallback. `--owner-firmware` installs the private build from `build/library-smk-owner/`, guarded by a matching factory identity. Private calibration and private packages must never enter `web/` or Git. Public cores read each device's own valid RF calibration. SMK Elite packaging is tested; physical validation uses SMK-37 Pro.

### Builds and checks

`python tools/build_bluetooth_probe.py --loader --board fm1 --output-dir build/library-fm1-public`

`python tools/build_bluetooth_probe.py --loader --board smk37 --output-dir build/library-smk-public`

The builder uses the pinned Hortator/AC79 SDK dependencies retained under the neighboring NESynth project. `python tools/public_library_firmware.py` stages only hash-verified calibration-free cores. `python tools/make_site.py` stages the explicit public asset allowlist; neither command publishes.

## Instrument controls

On SMK, Fader 1 controls volume. Fader 2 adjusts pad brightness from off to full (0-255); startup stays at 150 until the fader moves. Held pads go dark and relight on release.

Count white and black keys separately from the left. Assigned keys/pads light up. On physical FM-1 firmware 936, pressing a piano key turns off every piano-key LED mapped to the same action. They relight when the last matching key is released; unrelated keys stay lit. This applies to both Left keys, both Right keys, both Up keys, and the other assigned piano keys. The simulator retains its existing press effect.

These mappings are in the simulator and v2.0 firmware (internal build 938). B and A occupy the final two white keys, with no skipped white key. Select is to the left of Start: PLAY selects and RECORD starts. Install the v2.0 core to update older device mappings.

| Action | FM-1 | SMK37 |
| --- | --- | --- |
| Left | White 1 or 2 | White 4 or 5 |
| Down | White 3 | White 6 |
| Right | White 4 or 5 | White 7 or 8 |
| Up | Black 2 or 3 | Black 4 or 5 |
| A | White 16 (far right) | White 22 (far right) |
| B | White 15 | White 21 |
| Select / Start | PLAY / RECORD (also white 7 / 8) | PLAY / RECORD |
| Pad directions | - | Bottom 1 / 2 / 3 = Left / Down / Right; top 2 = Up |
| Pad B / A | - | Bottom 7 / 8 |

## Run and build

The checked-in browser assets can be served directly:

```sh
python tools/serve.py --port 8805 --rom-dir /path/to/your/roms
```

Open `http://localhost:8805/`. The optional local library is read-only and served only on loopback. File selection also works without a library.

Rebuilding requires Python 3, Node 22+ and Zig. Native firmware additionally needs WSL and the JieLi pi32v2 toolchain. Override the existing development-machine paths:

```sh
python tools/build.py web --zig /path/to/zig
python tools/build.py test --zig /path/to/zig
npm test
python tools/build.py smk37 --toolchain /path/to/jieli/toolchain
python tools/build.py fm1 --rom /path/to/game.gb --rom-capacity 524288
python tools/package_fm1.py --sdk /path/to/ac79-sdk
python tools/make_site.py
```

`ZIG` and `JIELI_TOOLCHAIN` also override build defaults. `tools/package_fm1.py` verifies pinned SDK inputs, loader placement, compression, package round trips and simulated flash behavior. It currently requires the development restore package for its bidirectional recovery tests. `tools/public_template.py` builds the original diagnostic template and verifies that the remaining cartridge capacity is erased padding. Private cartridge builds stay under ignored `build/`; never publish them.

`tools/make_site.py` creates `build/site/` from an explicit asset list, checks the diagnostic and template hashes, and includes all license texts. Publish that directory on the `gh-pages` branch. `npm test` covers ROM packing, protected USB code, install/restore handoffs, interrupted transfers, MIDI discovery and progress reporting; it needs no commercial ROMs. Optional `npm run test:library` uses a local catalog generated by `tools/catalog.py`.

## Limits

GB/DMG only; dual-mode games run in monochrome. No GBC-only/GBA games, link cable, rumble or save states. Browser RTC state does not persist while closed. Some games may have timing, visual or audio inaccuracies.

Hardware retains multiple cartridges in its game library, with a 256 KiB limit per game. The enlarged hardware display is 240 x 216, centered on the 240 x 240 panel. LCD refresh targets roughly 10 updates per second while CPU/audio retain Game Boy timing. Hardware save RAM is volatile.

## Sources and licenses

GPL-3.0-only integration with retained third-party notices. See [LICENSE](LICENSE), [upstream notices](vendor/felucca/LICENSING.md), and [source provenance](vendor/provenance.json).

- Peanut-GB and MiniGB APU: Mahyar Koshkouei, Alex Baines and credited contributors including Lior Halphon; MIT. Pinned Peanut-GB revision `d0bcca771c83a2638c93a9ae61f3d51f226dc905`.
- Felucca: Leo Kuroshita and Huegelton Instruments; GPL-3.0-only. SMK/MusicCoach adaptations by Chance Roth / ChanceTheMaker. Retained file hashes record the imported local reference sources.
- Browser packaging/updater: retained from ChanceTheMaker/sloop-smk, with original copyright notices and hashes in provenance.
- Three unmodified JieLi AC79 SDK package files: JieLi Technology; Apache-2.0. License and attribution accompany the public template.
- Original GameDude pixel logo, startup animation and diagnostic cartridge are project assets. Game Boy and Nintendo are trademarks of Nintendo. This independent project is not affiliated with Nintendo.

The browser simulator offers illustrated FM-1, SMK-37 Pro, SMK-37 Elite and classic Game Boy layouts. Lit device controls are playable. Enlarge screen moves the same running display above the hardware panel without resetting the game. Device artwork is retained under `vendor/illustrations` and generated with `python tools/make_device_art.py`.

Restore original firmware: connect the FM-1, expand the restore section, and press **Restore M-VAVE firmware**. GameDude downloads the verified official release automatically; there is no file picker. M-VAVE lists V15 (2026-07-30) as its latest FM-1 release, checked 2026-10-13. Because its download server does not allow browser cross-origin fetches, an unmodified copy is served with the site. The complete file hash and layout are checked before any MIDI transfer; the updater verifies the `FM-1_015` restart identity. The original manufacturer binary retains its own ownership and is not GPL-licensed GameDude code. Source URL and integrity metadata are in `web/firmware/original.json`. SMK restoration uses the selected Pro or Elite factory package and verifies its model and hash before writing. Maintainers can refresh the checked copy with `node tools/fetch_original.mjs`; a changed upstream release fails verification until reviewed.

Dual-core hardware trial: FM-1_934 was installed and verified responding over USB. CPU1 now completes immutable-frame scaling while CPU0 retains GB/APU emulation, audio interrupts, controls and USB. Initial hardware samples confirmed core ID 1, an increasing completed-job count, and no CPU1 faults or fallbacks. This corrects the earlier assumption that CPU1 never started: trial 933 reached its worker loop but fell back before accepting a frame. Build 934 fixes late-completion timeout handling and removes per-pixel division from the scaler. Host tests, FM-1/SMK builds and simulated install/restore pass. The owner confirmed normal picture, controls and sound. Longer stability testing remains pending. The v2.0 flasher serves build 938, retaining CPU1 scaling, the inner directional keys and grouped LED feedback on FM-1, with CPU1 also enabled on SMK. See [CPU1 trial notes](docs/CPU1_TRIAL.md).

The site uses a classic handheld-inspired theme: warm gray plastic, green LCD surfaces, blue labels and berry action buttons. One large molded console shell surrounds the content; the individual panels and device simulator shapes are retained.

The hero tour shows one instrument at a time, then zooms into its screen: FM-1 with Block Drop, SMK-37 Pro with Super Pixel, and SMK-37 Elite with Pocket Tennis. Pause or choose a device using the tour controls. Reduced-motion preferences start the tour paused. The screens are original AI-generated retro-style mock game illustrations, not commercial screenshots or included playable games. No commercial ROM is distributed.

Restore validation: `node tests/restore.mjs <official-FM-1-V15.fwsc>` exercises package rejection and install/resume routing without opening MIDI. The retained loader simulator also passed GameDude-to-original-V15 restoration with preservation of the boot region and writes restricted to the expected ranges. This does not substitute for a physical original-firmware restore test.


## Included homebrew

The Choose panel offers Tobu Tobu Girl, GB-Wordyl (English), 2048, Libbet and the Magic Floor, Breakout, Tic-Tac-Toe, Game of Life, Bytewave and Gamepad Tester. Select a cartridge and press **Play this cartridge**, then send it to the device library over Bluetooth or USB. Multiple games stay installed.

`web/homebrew/catalog.json` records upstream versions, hashes, licenses and sources. Full notices are in `web/homebrew/NOTICE.txt` and the site's Credits page. Original ROM bytes are retained; GB-Wordyl's GPL corresponding source archive is served alongside its ROM. A free download alone is not redistribution permission: only explicitly licensed cartridges are bundled.

`npm run test:homebrew` checks every bundled cartridge's identity, starts it in the shipped WebAssembly core, exercises controls for 1,800 frames and prepares FM-1 firmware while verifying the protected USB updater. This is smoke coverage, not complete gameplay or physical hardware testing. Bytewave uses timing-sensitive wave-channel synthesis; its audio is approximate. Browser battery RAM persists locally; FM-1 cartridge RAM is lost at restart.

The public staging tool only copies manifest-listed homebrew files after verifying their ROM/source hashes, licenses and DMG compatibility. The device library accepts games up to 256 KiB; the older single-cartridge packaging fixtures cover up to 512 KiB. Private local libraries remain excluded.

The top navigation includes an Install link to the firmware panel. The footer links to SMKLAB, Doom, Felucca SMK, Sloop SMK and Melodee SMK, matching the project family navigation.

The website, simulator and build 939 firmware share a solid italic GameDude wordmark. The small-screen artwork is generated from the same glyphs as the SVG logos; game storage capacity is unchanged.


## Windows SMK USB helper

The live website uses a local USB helper for SMK-37 Pro firmware installation on Windows. Chrome's Windows MIDI backend can freeze when the stock SMK disconnects and reappears as its updater. Closing a Web MIDI port or adding a delay did not fix that transition. The helper performs each USB stage in a separate process while the same live website displays progress. FM-1 and non-Windows browser installation are unchanged; Elite does not yet have the native helper path.

Install Python 3.12 and Node.js 22 or newer, download or clone this repository, then run from its folder:

```powershell
python tools/start_windows_usb.py
```

The first run installs pinned MIDI dependencies inside `build/python-deps` and downloads the SHA-256-verified official Pro 016 base if missing. Leave the helper running, use the normal live GameDude site, select SMK-37 Pro, and click Connect or Install. Allow Chrome's local-network permission if prompted. No Chrome flag changes or different browser are needed. Stop the helper with Ctrl+C when finished; start it again for later installs. Games still use the existing Bluetooth / USB uploader.

`--allow-hosted` explicitly enables the official GitHub Pages origin on a loopback-only listener. Other origins and Host headers are rejected. Hosted mutations require a per-process token obtained through the allowed capability request, JSON requests and fixed actions; callers cannot provide firmware bytes, shell commands or filesystem paths. The page fails before requesting Web MIDI when the Windows Pro helper is absent, incompatible or permission is denied. A failed status request does not retry programming automatically. The existing local service still works without hosted access enabled.

This helper identifies itself as `gamedude` and accepts only this site's pinned `SMK-37_939` core or the verified original Pro 016 firmware. The other GameDude edition uses its own port and package. Local ROM browsing remains loopback-only.

All three helpers use the same Windows file lock, so a second site cannot start an SMK operation during another update. Helper tests: `npm run test:usb-helper`; hosted browser regression: `node tests/native_smk_ui.mjs` with Playwright installed or `PLAYWRIGHT_MODULE` set.


## SMK flash compatibility release

The SMK update and stock-restore path now accepts the reported EB6014 flash
chip alongside 856014 and displays detailed loader failures. Update older
Windows USB-helper checkouts before installing this release.
See [release scope, evidence and recovery limits](docs/SMK_FLASH_COMPATIBILITY.md).
