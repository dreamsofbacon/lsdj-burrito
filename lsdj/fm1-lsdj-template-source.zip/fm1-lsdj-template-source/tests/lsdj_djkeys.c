/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_djkeys.h: the DJ layout's Play / Stop on OP4 / OP5. */
#include <assert.h>
#include <stdio.h>
#include "lsdj_djkeys.h"

#define PLAY (1u << LSDJ_DJ_KEY_PLAY)
#define STOP (1u << LSDJ_DJ_KEY_STOP)
#define C4   (1u << 7)   /* a key that is never the DJ's */

int main(void) {
    lsdj_dj_t d = {0};
    unsigned ev; uint32_t lit, soft;
    assert(PLAY == (1u << 8) && STOP == (1u << 10));   /* C#4 and D#4: key bits 8 and 10 */
    /* Not attached: keys pass, no events, lights left alone. */
    assert(lsdj_dj_keys(&d, PLAY | C4, 100, &ev) == (PLAY | C4) && ev == 0);
    assert(lsdj_dj_keys(&d, 0, 116, &ev) == 0 && ev == 0);
    assert(lsdj_dj_lights(&d, 116, 1, &lit, &soft) == 0 && !lit && !soft);
    /* DJ_DECK: 0..3 only. */
    assert(!lsdj_dj_set(&d, 4, 200) && d.state == 0);
    assert(lsdj_dj_set(&d, LSDJ_DJ_STOPPED, 200) && lsdj_dj_on(&d, 200));
    /* Attached: a press is an event, once, and the key is taken out while held. */
    assert(lsdj_dj_keys(&d, PLAY | C4, 216, &ev) == C4 && ev == LSDJ_DJ_EV_PLAY);
    assert(lsdj_dj_keys(&d, PLAY | C4, 232, &ev) == C4 && ev == 0);   /* held: no repeat */
    assert(lsdj_dj_keys(&d, 0, 248, &ev) == 0 && ev == 0);
    assert(lsdj_dj_keys(&d, STOP, 264, &ev) == 0 && ev == LSDJ_DJ_EV_STOP);
    assert(lsdj_dj_keys(&d, PLAY | STOP, 280, &ev) == 0 && ev == LSDJ_DJ_EV_PLAY);   /* STOP held, PLAY new */
    assert(lsdj_dj_keys(&d, 0, 296, &ev) == 0);
    /* Lights: stopped soft / soft. */
    assert(lsdj_dj_lights(&d, 300, 1, &lit, &soft) == (PLAY | STOP) && lit == 0 && soft == (PLAY | STOP));
    /* Waiting: Play blinks (on and off LSDJ_DJ_BLINK_MS each), Stop soft. */
    lsdj_dj_set(&d, LSDJ_DJ_WAITING, 300);
    { int on = 0, off = 0;
      for (uint32_t t = 300; t < 300 + 8 * LSDJ_DJ_BLINK_MS; t += LSDJ_DJ_BLINK_MS / 2) {
          lsdj_dj_lights(&d, t, 0, &lit, &soft);
          assert(soft == STOP && !(lit & STOP));
          if (lit & PLAY) on++; else off++;
      }
      assert(on == 8 && off == 8); }
    /* Playing: Play lit on the beat, soft between; Stop lit. */
    lsdj_dj_set(&d, LSDJ_DJ_PLAYING, 1000);
    assert(lsdj_dj_lights(&d, 1000, 1, &lit, &soft) && lit == (PLAY | STOP) && soft == 0);
    assert(lsdj_dj_lights(&d, 1000, 0, &lit, &soft) && lit == STOP && soft == PLAY);
    /* The page goes away: after LSDJ_DJ_MS the keys and lights are the FM-1's again. */
    assert(lsdj_dj_on(&d, 1000 + LSDJ_DJ_MS - 1) && !lsdj_dj_on(&d, 1000 + LSDJ_DJ_MS));
    assert(lsdj_dj_lights(&d, 1000 + LSDJ_DJ_MS, 1, &lit, &soft) == 0);
    assert(lsdj_dj_keys(&d, PLAY, 1000 + LSDJ_DJ_MS, &ev) == PLAY && ev == 0);
    /* Held over a detach: a key pressed while attached stays the DJ's until let go (no half notes). */
    assert(lsdj_dj_keys(&d, 0, 3000, &ev) == 0);
    lsdj_dj_set(&d, LSDJ_DJ_STOPPED, 3000);
    assert(lsdj_dj_keys(&d, STOP, 3016, &ev) == 0 && ev == LSDJ_DJ_EV_STOP);
    lsdj_dj_set(&d, LSDJ_DJ_DETACH, 3032);
    assert(!lsdj_dj_on(&d, 3032));
    assert(lsdj_dj_keys(&d, STOP, 3048, &ev) == 0 && ev == 0);   /* still held: still taken */
    assert(lsdj_dj_keys(&d, 0, 3064, &ev) == 0);
    assert(lsdj_dj_keys(&d, STOP, 3080, &ev) == STOP && ev == 0);   /* a new press: the FM-1's */
    /* A key held from before the attach is not an event and stays the FM-1's. */
    lsdj_dj_set(&d, LSDJ_DJ_STOPPED, 3096);
    assert(lsdj_dj_keys(&d, STOP, 3112, &ev) == STOP && ev == 0);
    /* fm1_ms wrapping round. */
    lsdj_dj_set(&d, LSDJ_DJ_STOPPED, 0xFFFFFF00u);
    assert(lsdj_dj_on(&d, 0x10u) && !lsdj_dj_on(&d, 0xFFFFFF00u + LSDJ_DJ_MS));
    puts("PASS: DJ keys: OP4 Play / OP5 Stop only while the page is attached, one event a press, keys taken while held; lights soft / blinking / beat");
    return 0;
}
