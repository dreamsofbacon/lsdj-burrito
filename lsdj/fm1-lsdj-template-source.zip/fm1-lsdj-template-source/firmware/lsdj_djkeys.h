/* SPDX-License-Identifier: GPL-3.0-only */
/* The web page's DJ layout on the FM-1's own keys (0.9.98-dev.4).
   While the page's DJ layout has this FM-1 on a deck it sends DJ_DECK (firmware/lsdj_link.h) with
   the deck's state every poll; the FM-1 counts as attached for LSDJ_DJ_MS after the last one.
   While attached:
     OP4 (C#4, key bit 8)  Play: the page starts the deck (DJ_KEY 0 sent to the page)
     OP5 (D#4, key bit 10) Stop: the page stops it (DJ_KEY 1)
   and the two keys do nothing else (no note, no page light). A key pressed while attached stays
   the DJ's until let go, so a note never starts or ends half way.
   Their lights, while attached:
     deck          OP4 (Play)                       OP5 (Stop)
     stopped       soft                             soft
     waiting       blinking (LSDJ_DJ_BLINK_MS)      soft
     playing       lit on each beat, soft between   lit
   Not attached: both keys and lights as before.
   Pure logic: tests/lsdj_djkeys.c. */
#pragma once
#include <stdint.h>

#define LSDJ_DJ_MS        3000u   /* attached this long after the last DJ_DECK (a background tab polls about once a second) */
#define LSDJ_DJ_BLINK_MS  80u     /* waiting: on and off this long each (~6 Hz) */
#define LSDJ_DJ_KEY_PLAY  8u      /* OP4, C#4 */
#define LSDJ_DJ_KEY_STOP  10u     /* OP5, D#4 */
#define LSDJ_DJ_KEYS      ((1u << LSDJ_DJ_KEY_PLAY) | (1u << LSDJ_DJ_KEY_STOP))
enum { LSDJ_DJ_DETACH = 0, LSDJ_DJ_STOPPED, LSDJ_DJ_WAITING, LSDJ_DJ_PLAYING };
enum { LSDJ_DJ_EV_PLAY = 1, LSDJ_DJ_EV_STOP = 2 };

typedef struct { uint8_t state; uint32_t ms, owned, prev; } lsdj_dj_t;

/* DJ_DECK: 1 if the state is valid (0..3). */
static int lsdj_dj_set(lsdj_dj_t *d, uint8_t state, uint32_t now_ms) {
    if (state > LSDJ_DJ_PLAYING) return 0;
    d->state = state; d->ms = now_ms;
    return 1;
}
static int lsdj_dj_on(const lsdj_dj_t *d, uint32_t now_ms) {
    return d->state != LSDJ_DJ_DETACH && now_ms - d->ms < LSDJ_DJ_MS;
}
/* Each frame with the keys held now (bit k = key k): returns the keys for the rest of the FM-1
   (the DJ's taken out); *ev gets LSDJ_DJ_EV_* for the keys pressed this frame. */
static uint32_t lsdj_dj_keys(lsdj_dj_t *d, uint32_t keys, uint32_t now_ms, unsigned *ev) {
    uint32_t down = keys & ~d->prev;
    d->prev = keys;
    *ev = 0;
    d->owned &= keys;   /* let go: the key is the FM-1's again */
    if (lsdj_dj_on(d, now_ms)) {
        d->owned |= down & LSDJ_DJ_KEYS;
        if (down & (1u << LSDJ_DJ_KEY_PLAY)) *ev |= LSDJ_DJ_EV_PLAY;
        if (down & (1u << LSDJ_DJ_KEY_STOP)) *ev |= LSDJ_DJ_EV_STOP;
    }
    return keys & ~d->owned;
}
/* The two keys' lights: returns the keys it sets (0: not attached, leave them as they were);
   *lit / *soft get the keys to show lit / soft. beat: LSDj is on a beat (lsdj_lights.h). */
static uint32_t lsdj_dj_lights(const lsdj_dj_t *d, uint32_t now_ms, int beat, uint32_t *lit, uint32_t *soft) {
    const uint32_t play = 1u << LSDJ_DJ_KEY_PLAY, stop = 1u << LSDJ_DJ_KEY_STOP;
    *lit = *soft = 0;
    if (!lsdj_dj_on(d, now_ms)) return 0;
    switch (d->state) {
    case LSDJ_DJ_WAITING:
        if ((now_ms / LSDJ_DJ_BLINK_MS) & 1u) *lit |= play;
        *soft |= stop;
        break;
    case LSDJ_DJ_PLAYING:
        if (beat) *lit |= play; else *soft |= play;
        *lit |= stop;
        break;
    default:
        *soft |= play | stop;
    }
    return LSDJ_DJ_KEYS;
}
