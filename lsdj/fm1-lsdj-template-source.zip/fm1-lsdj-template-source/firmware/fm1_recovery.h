/* SPDX-License-Identifier: GPL-3.0-only
 * GameDude adapter for Felucca's existing FM-1 USB updater.
 * Application writes are restricted to the existing OTA staging allocation. */
#include <string.h>
#define FELUCCA_OTA 1
#define FELUCCA_CDC 0
#define FELUCCA_UAC 0
#define FELUCCA_OTA_DRYRUN 0
/* Package identity, reported to M-UPGRADE: "FM-1_" + exactly 3 digits (4 = "incompatible"),
   newer number to update in place. LSDj alpha N = FM-1_9NN (alpha 12 = FM-1_912). Bump per release. */
#ifdef CART_SLOT_CAPACITY
#define FELUCCA_ID CART_SLOT_PRODUCT
#else
#define FELUCCA_ID "FM-1_976"
#endif
#define RING_PUBLISH() __asm__ volatile("csync" ::: "memory")
/* The flash driver may also write the LSDj save pool (lsdj_state.h, 0x97000..0xE0000 =
   Felucca's data store, FL_DATA); the updater below stays limited to OTA staging. */
#define OTA_RANGE_OK(off,n) FL_IN(off,n,0xe0000u,0xe5000u)
#define FL_RANGE_OK(off,n) (OTA_RANGE_OK(off,n)||FL_IN(off,n,0x97000u,0xe0000u))
#include "fm1_flash.h"
#include "../vendor/felucca/firmware/src/usb.c"
#include "../vendor/felucca/firmware/src/ota.c"
/* MIDI IN on the TRS jack (Felucca): clock and transport join the USB ring. */
#include "../vendor/felucca/firmware/src/midi_uart.c"
static uint8_t recovery_flash_ok;
/* board.c: the web page's link (firmware/lsdj_link.h); 1 = the frame was its. */
static int app_sysex_frame(const uint8_t *frame,uint32_t size);
static uint32_t ota_now_ms(void){return fm1_ms;}
static void ota_idle(void){fm1_wdt_feed();}
static int ota_erase(uint32_t off){
    uint32_t took;
    if(!recovery_flash_ok||!OTA_RANGE_OK(off,0x1000u)||(off&0xfffu))return -8;
    return fl_erase4k(off,&took);
}
static int ota_prog(uint32_t off,const void *p,uint32_t n){
    if(!recovery_flash_ok||!OTA_RANGE_OK(off,n))return -8;
    return fl_write(off,p,n);
}
static int ota_fread(uint32_t off,void *p,uint32_t n){
    if(off>0x100000u||n>0x100000u-off)return -8;
    uint32_t f=irq_save();int rc=FL_FAR(fl_read_ram)(off,p,n);irq_restore(f);return rc;
}
static void ota_show(uint32_t step,int32_t code){
    (void)code;
    /* Green progress bands; red on an update failure. */
    lcd_fill(0,0,240,240,step==9?0xf800:0);
    if(step<6)lcd_fill(20,100,step*40,24,0x07e0);
}
static void ota_commit(const uint8_t *parm){
    video_stop();gb_bootguard.pending=0;usb_detach();fm1_delay_ms(30);fm1_enter_update(parm);
}
static void recovery_tick(void){
    static uint32_t last,acc,sub;
    uint32_t now=fm1_ticks();acc+=now-last;last=now;
    fm1_ms+=acc/24000u;acc%=24000u;
    if(++sub==5){sub=0;usb_poll();uart_midi_poll();}
}
static void recovery_init(void){
    uint32_t f=irq_save();recovery_flash_ok=FL_FAR(fl_jedec_ram)()==0x856014u;irq_restore(f);
    /* Only stale OTA loader/record sectors; never presets, user data or calibration. */
    if(recovery_flash_ok)ota_boot_cleanup();
    /* TRS MIDI IN: PORTH is also written by the TIMER5 input scan, so no ISR meanwhile */
    f=irq_save();uart_midi_init();irq_restore(f);
    usb_start();
}
static void recovery_service(void){
    usb_retry(fm1_ms);
    /* Private non-commercial diagnostics: 7D 'G' 'D', version 1. Kept
       separate from all existing Felucca command IDs. Read-only. */
    const uint8_t *request;uint32_t request_size;
    if(ota_frame_get(&request,&request_size)&&request_size==4&&
       request[0]==0x7d&&request[1]=='G'&&request[2]=='D'&&(request[3]>=1&&request[3]<=3)){
        uint8_t version=request[3];ota_frame_done();
        uint32_t values[]={fm1_ms,gp_frame_count(),gp_audio_queued(),audio_count,scan_count,
            (uint32_t)master_raw,master_gain,key_lo,gp_error(),FM1_ALNK_CON0,FM1_ALNK_CON2,
            display_count,audio_underruns,fm1_in.buttons,input_buttons,input_seen,
            video_online,video_jobs,video_fallbacks,fm1_core1_fault.count,video_guard.barred,
            video_stage,video_core,video_launch_con,video_launch_pc,video_launch_emu,video_launch_dbg,
            fm1_core1_fault.pc,fm1_core1_fault.emu,fm1_core1_fault.dbg,
            video_launch_ready,video_retire_reason,video_retire_ticks,video_worker_jobs,video_work_max_ticks};
        uint8_t response[192]={0xf0,0x7d,'G','D',version};unsigned n=5;
        for(unsigned i=0;i<(version==1?16:version==2?21:sizeof values/sizeof values[0]);i++)
            for(unsigned j=0;j<5;j++)response[n++]=(uint8_t)((values[i]>>(j*7))&127);
        response[n++]=0xf7;ota_wire_send(response,n);
    }else if(ota_frame_get(&request,&request_size)&&app_sysex_frame(request,request_size)){
        ota_frame_done();
    }else ota_service();
#ifdef FM1_MIDI_IN
    /* Musical MIDI events (USB, TRS): to the board, with where they came from (1 USB, 2 TRS). */
    while(mi_r!=mi_w){uint32_t p=midi_in_q[mi_r%MQ],at=midi_in_ms[mi_r%MQ],src=midi_in_source[mi_r%MQ];mi_r++;FM1_MIDI_IN(p,at,src);}
    if(midi_in_overflow){uint32_t f=irq_save();mi_r=mi_w;midi_in_overflow=0;irq_restore(f);}
#else
    /* GameDude does not consume musical MIDI events. Keep that ring drained. */
    uint32_t f=irq_save();mi_r=mi_w;midi_in_overflow=0;irq_restore(f);
#endif
    if(usb.uboot_req){video_stop();audio_stop();gb_bootguard.pending=0;usb_detach();fm1_delay_ms(30);fm1_enter_uboot();}
    if(usb.ota_req){
        usb.ota_req=0;
        if(recovery_flash_ok){video_stop();audio_stop();ota_session();audio_start();}
    }
}
