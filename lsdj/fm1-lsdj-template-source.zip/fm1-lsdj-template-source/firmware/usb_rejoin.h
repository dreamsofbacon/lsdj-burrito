/* SPDX-License-Identifier: GPL-3.0-only */
/* The update loader's USB rejoin (vendor/felucca/firmware/loader/loader.c). After the restart into update mode
 * Windows sometimes misses the loader joining the bus (2026-11-12: Device Descriptor Request Failed; 2026-11-13:
 * nothing at all), and usb.c only retries a SIE that does not answer, never "on the bus but never set up": the FM-1
 * waited on UPDATE MODE: WAITING FOR THE INSTALLER until its cable was replugged. So, until the host first sets a
 * configuration, the loader leaves the bus and joins again (a replug in software) after 6, 12, 24 s, then every
 * 30 s. Once configured, never again: a write in progress is never touched. Pure logic (tests/usb_rejoin.c). */
#ifndef USB_REJOIN_H
#define USB_REJOIN_H
#include <stdint.h>

#define USB_REJOIN_FIRST_MS 6000u
#define USB_REJOIN_MAX_MS 30000u

typedef struct {
    uint32_t since, wait;   /* when the current attach began; how long to give it */
    uint8_t armed, done;    /* timing an attach; the host configured us (stop for good) */
    uint32_t rejoins;
} usb_rejoin_t;

/* once per loop: up = USB started (usb.up), config = the host's configuration (usb.config), detached = left the
   bus on purpose (usb.detached). 1 = leave the bus and join again now. */
static int usb_rejoin_due(usb_rejoin_t *r, uint32_t now, int up, int config, int detached)
{
    if (r->done || detached)
        return 0;
    if (config) {
        r->done = 1;
        return 0;
    }
    if (!up) {                                  /* no SIE yet: usb_retry's job; time the next attach afresh */
        r->armed = 0;
        return 0;
    }
    if (!r->armed) {
        r->armed = 1;
        r->since = now;
        if (!r->wait)
            r->wait = USB_REJOIN_FIRST_MS;
        return 0;
    }
    if (now - r->since < r->wait)
        return 0;
    r->since = now;
    r->wait = r->wait >= USB_REJOIN_MAX_MS / 2u ? USB_REJOIN_MAX_MS : r->wait * 2u;
    r->rejoins++;
    return 1;
}
#endif
